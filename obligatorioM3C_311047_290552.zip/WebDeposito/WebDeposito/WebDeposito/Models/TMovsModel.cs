﻿using Microsoft.AspNetCore.Mvc;

namespace WebDeposito.Models
{
    public class TMovsModel 
    {
        public string Nombre { get; set; }
        public int Total { get; set; }
    }
}
