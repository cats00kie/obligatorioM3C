﻿namespace WebDeposito.Models
{
    public class TipoMovimientoModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int TipoMovStock { get; set; }
    }
}
