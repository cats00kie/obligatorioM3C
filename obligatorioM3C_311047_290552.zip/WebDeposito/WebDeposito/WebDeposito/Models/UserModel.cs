﻿namespace WebDeposito.Models
{
    public class UserModel
    {
        public string Email { get; set; }
        public string PasswordSinEncript { get; set; }

    }
}
