﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Papeleria.LogicaAplicacion.DTOs
{
    public class TMovsDTO
    {
        public string Nombre { get; set; }
        public int Total { get; set; }
    }
}
