﻿using Papeleria.LogicaAplicacion.DTOs;

namespace Papeleria.LogicaAplicacion.InterfacesCasosDeUso.TMov
{
    public interface IUpdateTMov
    {
        void UpdateTMov(TipoMovimientoDTO tipoMovimiento);
    }
}