﻿using Papeleria.LogicaAplicacion.DTOs;

namespace Papeleria.LogicaAplicacion.InterfacesCasosDeUso.TMov
{
    public interface IDeleteTMov
    {
        void DeleteTMov(int id);
    }
}