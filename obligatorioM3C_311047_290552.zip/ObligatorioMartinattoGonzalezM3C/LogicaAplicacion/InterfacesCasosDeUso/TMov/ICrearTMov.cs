﻿using Papeleria.LogicaAplicacion.DTOs;

namespace Papeleria.LogicaAplicacion.InterfacesCasosDeUso.TMov
{
    public interface ICrearTMov
    {
        public void CrearTMov(TipoMovimientoDTO tMovDTO);
    }
}