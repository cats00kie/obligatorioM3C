﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Papeleria.LogicaNegocio.Entidades
{
    public enum TipoMovStock
    {
        REDUCE = 1,
        AGREGA = 2
    }
}
